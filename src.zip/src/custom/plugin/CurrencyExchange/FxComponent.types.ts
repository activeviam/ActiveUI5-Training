import {AWidgetState, MdxString} from "@activeviam/activeui-sdk";

// TODO: Ex4 - Add the query and the baseCurrency to the widgetState. The query should be typed as an mdx string
export interface FxComponentWidgetState extends AWidgetState {

}
